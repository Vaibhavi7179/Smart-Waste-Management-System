import random

BIN_HEIGHT = 30

def generate_distance():
    return random.randint(1, 30)

def calculate_fill(distance):
    fill = ((BIN_HEIGHT - distance) / BIN_HEIGHT) * 100
    return round(fill, 2)

def get_status(fill):
    if fill >= 80:
        return "FULL"
    elif fill >= 50:
        return "HALF FULL"
    else:
        return "EMPTY"