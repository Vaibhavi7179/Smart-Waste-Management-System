import streamlit as st
import pandas as pd
from simulator import generate_distance, calculate_fill, get_status
from datetime import datetime
import os

st.set_page_config(page_title="Smart Waste Management")

st.title("Smart Waste Management Dashboard")

distance = generate_distance()

fill = calculate_fill(distance)

status = get_status(fill)

alert = "YES" if fill >= 80 else "NO"

st.metric("Distance", f"{distance} cm")
st.metric("Fill Percentage", f"{fill}%")
st.metric("Status", status)

if fill >= 80:
    st.error("ALERT: Bin is Full")
else:
    st.success("Bin is Normal")

log = {
    "Timestamp": datetime.now(),
    "Distance": distance,
    "Fill Percentage": fill,
    "Status": status,
    "Alert": alert
}

df = pd.DataFrame([log])

file = "data/bin_log.csv"

if os.path.exists(file):
    df.to_csv(file, mode="a", header=False, index=False)
else:
    df.to_csv(file, index=False)

history = pd.read_csv(file)

st.subheader("Historical Data")

st.line_chart(history["Fill Percentage"])

st.dataframe(history.tail(10))